if 1:
    print("Hello " + "world")
    if 0:
        print("then")
        print("clause")
    elif 1:
        pass
    elif 1:
        pass
    else:
        print("else-clause")
